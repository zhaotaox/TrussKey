Low Power Wifi Datalogger
=========================

Low power WiFi datalogger example using an Arduino and CC3000 WiFi chip.  Check out the [guide on the Adafruit learning system](http://learn.adafruit.com/low-power-wifi-datalogging).
